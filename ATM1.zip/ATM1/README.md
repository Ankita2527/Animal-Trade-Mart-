# olx
olx website
... Features Overview: 
1-HTML , 2-CSS , 3-Bootstrap Framework , 4-PHP , 5-MYSql , 6-Responsive Layout Design , 7- Admin control panel .... pages: 1- index.html (home) , 2-page ads ,3- profile user ,4- Edit ads , 5-create ads , 6- control Accounts Users 
# https://olxphp.000webhostapp.com
# admin account : Admin@olx.com ,, password:123456
