-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2024 at 07:38 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olx`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertisments`
--

CREATE TABLE `advertisments` (
  `AdsID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Status` int(1) NOT NULL,
  `Details` varchar(200) NOT NULL,
  `Price` int(6) NOT NULL,
  `Image` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Title` varchar(50) NOT NULL,
  `UserID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `advertisments`
--

INSERT INTO `advertisments` (`AdsID`, `Date`, `Status`, `Details`, `Price`, `Image`, `Title`, `UserID`, `CategoryID`) VALUES
(83, '2019-03-30', 1, 'Breed - german female', 1399, '17094344592050136629_german female.jpg', 'German female', 0, 4),
(85, '2019-03-30', 1, 'Breed - Bulldog , Age - 6 Month', 55, '17094345181854624790_Bulldog.jpg', 'Bulldog', 0, 4),
(92, '2024-03-04', 1, 'Breed - Labrador , Age - 1 Year ,  color - golden', 2000, '17095308422027129835_labrador3.jpg', 'Labrador', 2, 4),
(93, '2024-03-04', 1, 'Breed - Golden-puppy Age - 1 month', 2500, '1709530925542638006_golden-puppy.png', 'Golden-puppy', 2, 4),
(94, '2024-03-04', 1, 'Breed - Pomerian , age - 1 Year', 3000, '1709531014646659243_slider1.jpeg', 'Pomerian', 2, 4),
(95, '2024-03-04', 1, 'Breed - Great_dane , Age - 1 year', 4000, '1709531244527078752_great_dane.jpg', 'Great_dane', 2, 4),
(96, '2024-03-04', 1, 'Breed - Grey Ragdoll , Age - 3 month', 1500, '1709531332746129380_grey ragdoll.jpeg', 'Grey Ragdoll', 18, 3),
(97, '2024-03-04', 1, 'Breed - persian , age - 3 month', 8000, '17095314022110188785_persian baby.jpg', 'Persian ', 18, 3),
(98, '2024-03-04', 1, 'Breed - Golden Persian , Age - 7 month', 6000, '1709531491354800743_persian golden.jpg', 'Golden Persian ', 18, 3),
(99, '2024-03-04', 1, 'Breed - Ragdoll , Age - 6 month', 3000, '1709531542373373620_Ragdoll.jpg', 'Ragdoll', 18, 3),
(100, '2024-03-04', 1, 'Breed - Blue Cross , Age  - 2 month', 2000, '17095316101855872363_blue cross cat.jpg', 'Blue Cross ', 18, 3),
(101, '2024-03-04', 1, 'Breed - ragdoll (kitten) Age - 1 month', 6000, '1709531680541742789_ragdoll kitten.jpg', 'Ragdoll kitten', 18, 3),
(102, '2024-03-04', 1, 'Breed - Gersey  , Age - 1 year', 35000, '17095318212043117145_gersey cow1.jpg', 'Gersey ', 19, 5),
(103, '2024-03-04', 1, 'Breed - Gersey , Age - 2 year ', 45000, '17095318691245050501_gersey cow2.jpg', 'Gersey ', 19, 5),
(104, '2024-03-04', 1, 'Breed - Gersey  , Age - 6 month', 15000, '1709531913765463345_gersey baby.jpg', 'Calf', 19, 5);

-- --------------------------------------------------------

--
-- Table structure for table `areas`
--

CREATE TABLE `areas` (
  `areaID` int(11) NOT NULL,
  `areaName` varchar(20) NOT NULL,
  `cityID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `areas`
--

INSERT INTO `areas` (`areaID`, `areaName`, `cityID`) VALUES
(1, 'koregaon', 1),
(2, 'Karad', 1),
(3, 'Purandar', 2),
(4, 'Junnar', 2),
(9, 'Solapur', 5),
(13, 'Shirala', 4),
(14, 'Miraj', 4),
(15, 'Kagal', 3),
(16, 'Panhala', 3),
(18, 'Pandharpur', 5);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CategoryID`, `CategoryName`) VALUES
(3, 'cat'),
(4, 'dog'),
(5, 'cow');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `cityID` int(11) NOT NULL,
  `cityName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`cityID`, `cityName`) VALUES
(1, 'Satara'),
(2, 'Pune'),
(3, 'Kolhapur'),
(4, 'Sangli'),
(5, 'Solapur');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Status` int(1) NOT NULL,
  `Details` varchar(100) NOT NULL,
  `UserID` int(11) NOT NULL,
  `AdsID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `UserID` int(11) NOT NULL,
  `AdsID` int(11) NOT NULL,
  `details` varchar(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`UserID`, `AdsID`, `details`, `Date`) VALUES
(2, 85, 'bad', '2019-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Phone` int(11) NOT NULL,
  `type` int(1) NOT NULL,
  `Status` int(1) DEFAULT NULL,
  `areaID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `UserName`, `Email`, `Password`, `Phone`, `type`, `Status`, `areaID`) VALUES
(0, 'Admin', 'Admin@Admin', '11', 1, 1, 2, 1),
(2, 'Ankita', 'ankita@gmail.com', 'ankita', 853012675, 1, 1, 1),
(18, 'Disha', 'disha@gmail.com', 'disha', 123456, 1, 1, 1),
(19, 'sakshi', 'sakshi@gmail.com', 'sakshi', 12345, 1, 1, 14),
(20, 'Tanaya', 'tanaya@gmail.com', 'tanaya', 123, 1, 1, 13),
(21, 'suchi', 'suchi@gmail.com', 'suchi', 12, 2, 1, 9),
(22, 'priti', 'priti@gmail.com', 'priti', 32, 1, 1, 16),
(23, 'abc', 'abc@gmail.com', 'abc', 11, 1, 1, 18),
(24, 'xyz', 'xyz@gmail.com', 'xyz', 12332, 1, 1, 15),
(25, '123', '123@gmail.com', '123', 856, 2, 1, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertisments`
--
ALTER TABLE `advertisments`
  ADD PRIMARY KEY (`AdsID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CategoryID` (`CategoryID`);

--
-- Indexes for table `areas`
--
ALTER TABLE `areas`
  ADD PRIMARY KEY (`areaID`),
  ADD KEY `cityID` (`cityID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`cityID`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`),
  ADD KEY `AdsID` (`AdsID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`UserID`,`AdsID`),
  ADD KEY `adsidFK` (`AdsID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `UserName` (`UserName`),
  ADD UNIQUE KEY `Phone` (`Phone`),
  ADD KEY `areaID` (`areaID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertisments`
--
ALTER TABLE `advertisments`
  MODIFY `AdsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `areas`
--
ALTER TABLE `areas`
  MODIFY `areaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `cityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `advertisments`
--
ALTER TABLE `advertisments`
  ADD CONSTRAINT `catidFK` FOREIGN KEY (`CategoryID`) REFERENCES `categories` (`CategoryID`),
  ADD CONSTRAINT `useridFK` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `areas`
--
ALTER TABLE `areas`
  ADD CONSTRAINT `cityidFK` FOREIGN KEY (`cityID`) REFERENCES `cities` (`cityID`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `AdsFK` FOREIGN KEY (`AdsID`) REFERENCES `advertisments` (`AdsID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userFK` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `Userridfk` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`),
  ADD CONSTRAINT `adsidFK` FOREIGN KEY (`AdsID`) REFERENCES `advertisments` (`AdsID`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `areaidFK` FOREIGN KEY (`areaID`) REFERENCES `areas` (`areaID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
