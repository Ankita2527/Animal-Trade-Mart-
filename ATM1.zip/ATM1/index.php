<?php
include_once("includes/functions.php");
?>
<!DOCTYPE html>
<head>
<title>links</title>
<link rel="shotcuticon" href="assets/img/olx.png">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="assets/css/style.css"/>
<script>

    function getareas(cid){
        $(document).ready(function(){
            $.get("getAreas.php?cid="+cid, function(data, status){
                $("#areaDiv").html(data);
            });
        });
    }

</script>
</head>
<body background="assets/img/bg5.jpg" height="1000px">
    

<marquee><img src="assets/img/bone-walking.gif" height="50px"></marquee>

<?php
drawHeader();
?>

<center><img src="assets/img/Screenshot 2024-03-22 203617.png" height="150px" width="1100"></center>

<div class='container'>
    <div class="btn-group btn-group-justified col-sm-12 m-2">
        <a href="index.php?category=dog" class="btn btnselect"><img src="assets/img/beagle.gif" height="60px" ></a>
        <a href="index.php?category=cat" class="btn btnselect"><img src="assets/img/cat.gif" height="60px" ></a>
        <a href="index.php?category=cow" class="btn btnselect"><img src="assets/img/cow.gif" height="60px" ></a>
    </div>
</div>

<section class="ads">
    <div class="container">
        <div class="row" >
            <?php 
            // Get DB products and display them based on the selected category
            if (isset($_GET['category'])) {
                $category = $_GET['category'];
                $result = mysqli_query($clink, "SELECT * FROM advertisments WHERE CategoryID IN (SELECT CategoryID FROM categories WHERE CategoryName = '$category')");
            } else {
                // If no category is selected, display all advertisements
                $result = mysqli_query($clink, "SELECT * FROM advertisments");
            }
            
            if(mysqli_num_rows($result) > 0) {
                // Show advertisements
                while($row = mysqli_fetch_assoc($result)) {
                    if($row['Status'] == 1 || isLogged() == 2) {
                        echo "<div class='col-md-4 col-sm-6'>
                                <div class='card'> 
                                    <img class='' src='assets/img/{$row['Image']}' class='card-img-top' alt='...'>
                                    <span class='float-left'> RS {$row['Price']}</span>
                                    <div class='card-body'>
                                        <h5 class='card-title'>{$row['Title']}</h5>
                                        <p class='card-text'>{$row['Details']}</p>
                                        <a href='pageads.php?ADS-ID={$row['AdsID']}' class='btn btn-primary'>More Details</a>"; 
                        if ($row['Status'] == 1 && (isLogged() == 2)) {
                            echo "<a href='adsshoworhide.php?ADS-ID={$row['AdsID']}' class='btn btn-danger ml-2'>Hide</a>";
                        } else if ($row['Status'] == 0 && (isLogged() == 2)) {
                            echo "<a href='adsshoworhide.php?ADS-ID={$row['AdsID']}' class='btn btn-primary ml-2'>Show</a>";
                        }
                        echo "</div></div></div>";
                    }
                }
            } else {
                outputMessage("No products found in our catalog", 'warning');
            }
            ?>
        </div>
    </div>
</section>

    </div>
</section>

<script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<?php
include_once("includes/footer.php");
?>
</body>
</html>