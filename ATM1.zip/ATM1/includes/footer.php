<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
    /* Footer styles */
.footer {
    background-color: #333;
    color: #fff;
    padding: 50px 0;
}

.footer h4 {
    color: #fff;
}

.footer p {
    color: #ccc;
}

.social-icons {
    list-style: none;
    padding: 0;
}

.social-icons li {
    display: inline-block;
    margin-right: 10px;
}

.social-icons li a {
    color: #fff;
    font-size: 20px;
}

.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  border-radius: 50%;
}

/* Add a hover effect if you want */
.fa:hover {
  opacity: 0.7;
}

/* Set a specific color for each brand */

/* Facebook */
.fa-facebook {
  background: #3B5998;
  color: white;
}
/* Twitter */
.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-instagram {
  background: #3B5998;
  color: white;
}


</style>
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <!-- Your footer content here -->
                <h4>About Us</h4>
                <p>The Animal Trade Mart is a platform designed to facilitate the buying and selling of pets in a secure and user-friendly environment </p>
            </div>
            <div class="col-md-4">
                <!-- Your footer content here -->
                <h4>Contact Us</h4>
                <p>Email: atm@market.com</p>
                <p>Phone: +1234567890</p>
            </div>
            <div class="col-md-4">
                <!-- Your footer content here -->
                <h4>Follow Us</h4>
                <p>Connect with us on social media:</p>
                <ul class="social-icons">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" ><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" ><i class="fa fa-instagram"></i></a></li>
                    

                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



                </ul>
            </div>
        </div>
    </div>
</footer>